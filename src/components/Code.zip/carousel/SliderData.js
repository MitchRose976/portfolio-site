// import pic1 from '../../images/pic1.jpg';
// import pic2 from '../../images/pic2.jpg';
// import pic3 from '../../images/pic3.jpg';

export const SliderData = [
    {
        image: 'https://images.pexels.com/photos/4969837/pexels-photo-4969837.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
        image: 'https://images.pexels.com/photos/4969841/pexels-photo-4969841.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }, 
    {
        image: 'https://images.pexels.com/photos/4969845/pexels-photo-4969845.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }
];